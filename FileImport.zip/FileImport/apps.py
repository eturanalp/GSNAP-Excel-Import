from django.apps import AppConfig


class FileimportConfig(AppConfig):
    name = "FileImport"
