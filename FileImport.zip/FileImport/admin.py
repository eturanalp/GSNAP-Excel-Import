from django.contrib import admin
from .models import FileImport


admin.site.register(FileImport)
